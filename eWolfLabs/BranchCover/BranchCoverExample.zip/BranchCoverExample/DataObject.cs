﻿namespace BranchCoverExample
{
    public class DataObject
    {
        public int Value = 0;
    }
}
